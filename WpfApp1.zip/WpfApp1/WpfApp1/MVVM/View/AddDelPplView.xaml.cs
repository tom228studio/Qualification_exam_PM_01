﻿using Npgsql;
using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;


namespace WpfApp1.MVVM.View
{
    /// <summary>
    /// Логика взаимодействия для AddDelPplView.xaml
    /// </summary>
    public partial class AddDelPplView : UserControl
    {

        private string connstring = String.Format("Server={0};Port={1};" +
            "User Id={2};Password={3};Database={4};",
            "localhost", 5432, "postgres",
            "123", "postgres");

        private NpgsqlConnection conn;
        private string sql;
        private NpgsqlCommand cmd;
        private DataTable dt;

        public AddDelPplView()
        {
            InitializeComponent();
            conn = new NpgsqlConnection(connstring);
        }

        private void Btn_Insert(object sender, RoutedEventArgs e)
        {
            try
            {
                conn.Open();
                sql = @"select * from st_Insert(:_firstname,:_midname,:_lastname,:_score)";
                cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("_firstname",FirstName.Text);
                cmd.Parameters.AddWithValue("_midname", MiddleName.Text);
                cmd.Parameters.AddWithValue("_lastname", LastName.Text);
                cmd.Parameters.AddWithValue("_score", double.Parse(Score.Text));
                cmd.ExecuteScalar();
                conn.Close();
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show("Cant insert " + ex.Message);
            }
            
        }

        private void Btn_Update(object sender, RoutedEventArgs e)
        {
            try
            {
                conn.Open();
                sql = @"select * from st_update(:_id,:_firstname,:_midname,:_lastname,:_score)";
                cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("_id", int.Parse(ID.Text));
                cmd.Parameters.AddWithValue("_firstname", FirstName.Text);
                cmd.Parameters.AddWithValue("_midname", MiddleName.Text);
                cmd.Parameters.AddWithValue("_lastname", LastName.Text);
                cmd.Parameters.AddWithValue("_score", double.Parse(Score.Text));
                cmd.ExecuteScalar();
                conn.Close();
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show("Cant update " + ex.Message);
            }
        }

        private void Btn_Delete(object sender, RoutedEventArgs e)
        {
            try
            {
                conn.Open();
                sql = @"select * from st_delete(:_id)";
                cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("_id",int.Parse(ID.Text));
                cmd.ExecuteScalar();
                conn.Close();
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show("Cant Del " + ex.Message);
            }
        }

        private void Btn_Select(object sender, RoutedEventArgs e)
        {

            conn.Open();
            sql = @"select * from st_select();";
            cmd = new NpgsqlCommand(sql, conn);
            dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            conn.Close();
            UserGrid.ItemsSource = null;
            UserGrid.ItemsSource = dt.DefaultView;
        }
    }
}
