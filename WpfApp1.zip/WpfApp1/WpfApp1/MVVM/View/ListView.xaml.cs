﻿using Npgsql;
using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;

namespace WpfApp1.MVVM.View
{
    /// <summary>
    /// Логика взаимодействия для List.xaml
    /// </summary>
    public partial class ListView : UserControl
    {
        private string connstring = String.Format("Server={0};Port={1};" +
            "User Id={2};Password={3};Database={4};",
            "localhost", 5432, "postgres",
            "123", "postgres");

        private NpgsqlConnection conn;
        private string sql;
        private NpgsqlCommand cmd;
        private DataTable dt;

        public ListView()
        {
            InitializeComponent();
            conn = new NpgsqlConnection(connstring);
        }
        private void Btn_Select(object sender, RoutedEventArgs e)
        {

           conn.Open();
           sql = @"select * from st_select();";
           cmd = new NpgsqlCommand(sql, conn);
           dt = new DataTable();
           dt.Load(cmd.ExecuteReader());
           conn.Close();
           UserGrid.ItemsSource = null;
           UserGrid.ItemsSource = dt.DefaultView;
        }
    }
}
