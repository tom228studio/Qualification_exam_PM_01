﻿using System;
using WpfApp1.Core;

namespace WpfApp1.MVVM.ViewModel
{
    class MainViewModel : ObservableObject
    {

        public RelayCommand HomeViewCommand { get; set; }

        public RelayCommand ListViewCommand { get; set; }

        public RelayCommand AddDelPplViewCommand { get; set; }

        public HomeViewModel HomeVM { get; set; }

        public ListViewModel ListVM { get; set; }

        public AddDelPplViewModel AddDelPplVM { get; set; }

        private object _currentView;

        public object CurrentView
        {
            get { return _currentView; }
            set 
            { 
                _currentView = value;
                OnPropertyChanged();
            }
        }

        public MainViewModel()
        {
            HomeVM = new HomeViewModel();
            ListVM = new ListViewModel();
            AddDelPplVM = new AddDelPplViewModel();

            CurrentView = HomeVM;

            HomeViewCommand = new RelayCommand(o =>
            {
                CurrentView = HomeVM;
            });

            ListViewCommand = new RelayCommand(o =>
            {
                CurrentView = ListVM;
            });

            AddDelPplViewCommand = new RelayCommand(o =>
            {
                CurrentView = AddDelPplVM;
            });
        }
    }
}
